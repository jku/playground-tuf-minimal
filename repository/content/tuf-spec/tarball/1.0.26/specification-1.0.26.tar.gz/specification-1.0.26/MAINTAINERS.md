# Maintainers

## Consensus Builder

* Justin Cappos ([JustinCappos](https://github.com/JustinCappos))

## TAP Editors

* Justin Cappos ([JustinCappos](https://github.com/JustinCappos))
* Trishank Karthik Kuppusamy ([trishankatdatadog](https://github.com/trishankatdatadog))
* Joshua Lock ([joshuagl](https://github.com/joshuagl))
* Marina Moore ([mnm678](https://github.com/mnm678))
* Lukas Pühringer ([lukpueh](https://github.com/lukpueh))
