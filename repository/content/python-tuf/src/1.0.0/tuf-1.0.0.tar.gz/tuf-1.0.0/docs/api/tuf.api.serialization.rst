Serialization
=============================

.. automodule:: tuf.api.serialization

JSON serialization
-----------------------------

.. automodule:: tuf.api.serialization.json
   :show-inheritance:
