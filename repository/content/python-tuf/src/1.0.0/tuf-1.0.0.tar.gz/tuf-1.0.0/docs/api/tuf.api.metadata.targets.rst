Targets class
---------------------------------

.. autoclass:: tuf.api.metadata.Targets
