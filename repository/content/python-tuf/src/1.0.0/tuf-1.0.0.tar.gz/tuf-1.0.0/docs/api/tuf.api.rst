Metadata API
===============

.. toctree::

   tuf.api.metadata.metadata
   tuf.api.metadata.root
   tuf.api.metadata.timestamp
   tuf.api.metadata.snapshot
   tuf.api.metadata.targets

.. toctree::
   :hidden:

   tuf.api.metadata.supporting
   tuf.api.serialization

.. automodule:: tuf.api.metadata
   :no-members:
   :no-inherited-members:
