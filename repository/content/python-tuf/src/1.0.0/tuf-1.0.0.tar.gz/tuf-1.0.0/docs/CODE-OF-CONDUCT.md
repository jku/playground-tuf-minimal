## The Update Framework Community Code of Conduct

The Update Framework follows the [CNCF Code of
Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md)
