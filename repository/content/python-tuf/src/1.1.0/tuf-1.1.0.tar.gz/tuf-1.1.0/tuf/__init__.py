# Copyright New York University and the TUF contributors
# SPDX-License-Identifier: MIT OR Apache-2.0

"""TUF
"""

# This value is used in the requests user agent.
__version__ = "1.1.0"
