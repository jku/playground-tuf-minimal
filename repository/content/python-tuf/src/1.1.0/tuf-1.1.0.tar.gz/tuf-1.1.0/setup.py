# This file exists to keep dependabot happy:
# https://github.com/dependabot/dependabot-core/issues/4483
from setuptools import setup
setup()
