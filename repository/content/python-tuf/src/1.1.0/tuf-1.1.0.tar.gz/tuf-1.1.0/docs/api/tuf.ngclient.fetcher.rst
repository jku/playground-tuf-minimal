Fetcher
============

.. automodule:: tuf.ngclient.fetcher
   :undoc-members:
