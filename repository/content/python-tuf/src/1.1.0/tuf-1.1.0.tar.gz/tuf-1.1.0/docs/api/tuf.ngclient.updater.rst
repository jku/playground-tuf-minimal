Updater
=========

.. automodule:: tuf.ngclient.updater
