Timestamp class
---------------------------------

.. autoclass:: tuf.api.metadata.Timestamp
