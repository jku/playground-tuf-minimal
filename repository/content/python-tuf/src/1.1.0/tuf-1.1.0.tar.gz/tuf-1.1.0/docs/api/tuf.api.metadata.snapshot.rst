Snapshot class
---------------------------------

.. autoclass:: tuf.api.metadata.Snapshot
