Root class
---------------------------------

.. autoclass:: tuf.api.metadata.Root
