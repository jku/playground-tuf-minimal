Metadata class
---------------------------------

.. autoclass:: tuf.api.metadata.Metadata
